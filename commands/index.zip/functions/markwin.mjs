import { respond } from "../discord/interaction-response.mjs";

export async function markWin(discordEvent) {
    return
}